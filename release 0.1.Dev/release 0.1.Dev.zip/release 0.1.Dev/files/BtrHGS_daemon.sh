#!/sbin/openrc-run
command="python3 /etc/BtrHGS/BtrHGS_frontend.py"


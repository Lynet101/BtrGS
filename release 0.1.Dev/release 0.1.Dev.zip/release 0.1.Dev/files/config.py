dm='lightdm' #set your display manager
d_pci1='0000:01:00.0' #full pci address to nvidia gpu
d_pci2='0000:01:00.1' #full pci address to nvidia audio